import React, { useState, useRef } from 'react';
import { Menu, X, Plus, MessageCircle, Settings, Upload, Send, User, FileText } from 'lucide-react';

interface ChatMessage {
  type: 'user' | 'llm';
  content: string;
  timestamp: Date;
}

interface PreviousChat {
  id: number;
  title: string;
  date: string;
}

interface SidebarItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  action: () => void;
}

type ViewType = 'chat' | 'allChats' | 'settings';

const Dashboard: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [currentView, setCurrentView] = useState<ViewType>('chat');
  const [uploadedPDF, setUploadedPDF] = useState<File | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [userInput, setUserInput] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [previousChats, setPreviousChats] = useState<PreviousChat[]>([
    { id: 1, title: 'Document Analysis Chat', date: '2024-07-01' },
    { id: 2, title: 'Research Paper Discussion', date: '2024-06-28' },
    { id: 3, title: 'Contract Review', date: '2024-06-25' }
  ]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePDFUpload = (event: React.ChangeEvent<HTMLInputElement>): void => {
    const file = event.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      setUploadedPDF(file);
      const url = URL.createObjectURL(file);
      setPdfUrl(url);
    }
  };

  const handleNewChat = (): void => {
    setChatHistory([]);
    setUserInput('');
    setCurrentView('chat');
    setIsSidebarOpen(false);
  };

  const handleSendMessage = async (): Promise<void> => {
    if (!userInput.trim()) return;

    const userMessage: ChatMessage = { type: 'user', content: userInput, timestamp: new Date() };
    setChatHistory(prev => [...prev, userMessage]);
    setIsLoading(true);

    // Simulate LLM response
    setTimeout(() => {
      const llmResponse: ChatMessage = {
        type: 'llm',
        content: `I've analyzed your request: "${userInput}". ${uploadedPDF ? `Based on the uploaded PDF "${uploadedPDF.name}", here's my response: This appears to be a comprehensive analysis of the document content. I can help you with specific questions about the document, summarize key points, or extract relevant information.` : 'Please upload a PDF document for me to analyze and provide more specific insights.'}`,
        timestamp: new Date()
      };
      setChatHistory(prev => [...prev, llmResponse]);
      setIsLoading(false);
    }, 1500);

    setUserInput('');
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>): void => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const sidebarItems: SidebarItem[] = [
    { id: 'newChat', label: 'New Chat', icon: Plus, action: handleNewChat },
    { id: 'allChats', label: 'All Previous Chats', icon: MessageCircle, action: () => { setCurrentView('allChats'); setIsSidebarOpen(false); } },
    { id: 'settings', label: 'Settings', icon: Settings, action: () => { setCurrentView('settings'); setIsSidebarOpen(false); } }
  ];

  const renderMainContent = (): JSX.Element => {
    switch (currentView) {
      case 'allChats':
        return (
          <div className="flex-1 p-6 bg-gray-50">
            <h2 className="text-2xl font-bold mb-6 text-gray-800">Previous Chats</h2>
            <div className="space-y-4">
              {previousChats.map((chat: PreviousChat) => (
                <div key={chat.id} className="bg-white rounded-lg shadow-sm border p-4 hover:shadow-md transition-shadow cursor-pointer">
                  <h3 className="font-semibold text-gray-800">{chat.title}</h3>
                  <p className="text-gray-600 text-sm mt-1">{chat.date}</p>
                </div>
              ))}
            </div>
          </div>
        );
      
      case 'settings':
        return (
          <div className="flex-1 p-6 bg-gray-50">
            <h2 className="text-2xl font-bold mb-6 text-gray-800">User Profile</h2>
            <div className="bg-white rounded-lg shadow-sm border p-6">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center">
                  <User className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-800">John Doe</h3>
                  <p className="text-gray-600">john.doe@example.com</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Display Name</label>
                  <input type="text" className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" defaultValue="John Doe" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input type="email" className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" defaultValue="john.doe@example.com" />
                </div>
                <button className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors">
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        );
      
      default:
        return (
          <div className="flex-1 flex">
            {/* PDF Viewer Section */}
            <div className="w-1/2 border-r border-gray-200 bg-gray-50 flex flex-col">
              <div className="p-4 border-b border-gray-200 bg-white">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-gray-800">PDF Viewer</h3>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors flex items-center space-x-2"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Upload PDF</span>
                  </button>
                </div>
              </div>
              
              <div className="flex-1 p-4">
                {pdfUrl ? (
                  <div className="h-full bg-white rounded-lg shadow-sm border overflow-hidden">
                    <iframe
                      src={pdfUrl}
                      className="w-full h-full"
                      title="PDF Viewer"
                    />
                  </div>
                ) : (
                  <div className="h-full bg-white rounded-lg shadow-sm border flex items-center justify-center">
                    <div className="text-center text-gray-500">
                      <FileText className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                      <p className="text-lg font-medium">No PDF uploaded</p>
                      <p className="text-sm mt-2">Click "Upload PDF" to get started</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Chat Section */}
            <div className="w-1/2 flex flex-col">
              <div className="p-4 border-b border-gray-200 bg-white">
                <h3 className="font-semibold text-gray-800">AI Assistant</h3>
              </div>
              
              {/* Chat History */}
              <div className="flex-1 p-4 overflow-y-auto bg-gray-50">
                <div className="space-y-4">
                  {chatHistory.length === 0 ? (
                    <div className="text-center text-gray-500 py-8">
                      <MessageCircle className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                      <p>Start a conversation about your PDF</p>
                    </div>
                  ) : (
                    chatHistory.map((message: ChatMessage, index: number) => (
                      <div key={index} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                          message.type === 'user' 
                            ? 'bg-blue-500 text-white' 
                            : 'bg-white text-gray-800 border border-gray-200'
                        }`}>
                          <p className="text-sm">{message.content}</p>
                          <p className={`text-xs mt-1 ${message.type === 'user' ? 'text-blue-100' : 'text-gray-500'}`}>
                            {message.timestamp.toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-white text-gray-800 border border-gray-200 px-4 py-2 rounded-lg">
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Input Section */}
              <div className="p-4 border-t border-gray-200 bg-white">
                <div className="flex space-x-3">
                  <textarea
                    value={userInput}
                    onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setUserInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask questions about your PDF..."
                    className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    rows={2}
                  />
                  <button
                    onClick={handleSendMessage}
                    disabled={!userInput.trim() || isLoading}
                    className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className={`${isSidebarOpen ? 'w-64' : 'w-0'} transition-all duration-300 bg-white shadow-lg overflow-hidden`}>
        <div className="p-4 border-b border-gray-200">
          <h2 className="font-bold text-lg text-gray-800">PDF Chat App</h2>
        </div>
        <nav className="p-4">
          <ul className="space-y-2">
            {sidebarItems.map((item: SidebarItem) => (
              <li key={item.id}>
                <button
                  onClick={item.action}
                  className="w-full flex items-center space-x-3 px-3 py-2 text-left text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200 px-4 py-3">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
            >
              {isSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <h1 className="text-xl font-semibold text-gray-800">
              {currentView === 'chat' ? 'PDF Analysis' : 
               currentView === 'allChats' ? 'Previous Chats' : 'Settings'}
            </h1>
            <div className="w-10"></div>
          </div>
        </header>

        {/* Main Content Area */}
        {renderMainContent()}
      </div>

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf"
        onChange={handlePDFUpload}
        className="hidden"
      />
    </div>
  );
};

export default Dashboard;